"""Core evaluation engine."""
import ast
import operator
from calculator.operations import OPERATORS


class Engine:
    def __init__(self):
        self.ops = OPERATORS

    def compute(self, expr: str) -> float:
        tree = ast.parse(expr, mode="eval")
        return self._walk(tree.body)

    def _walk(self, node):
        if isinstance(node, ast.Constant):
            return float(node.value)
        elif isinstance(node, ast.BinOp):
            l = self._walk(node.left)
            r = self._walk(node.right)
            op_fn = self.ops.get(type(node.op))
            if op_fn:
                return op_fn(l, r)
        raise ValueError("Invalid expression")
