"""Output formatting utilities."""


def format_result(value: float, decimal_places: int = 2) -> str:
    return f"Result: {value:.{decimal_places}f}"
