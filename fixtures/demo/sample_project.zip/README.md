# Multi-File Math Parser
Student demo multi-file project for CodeOrigin AI analysis.
