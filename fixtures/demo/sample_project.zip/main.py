"""CLI Entry point for student application."""
from calculator.core import Engine
from calculator.formatter import format_result


def run():
    engine = Engine()
    val = engine.compute("3 + 7")
    print(format_result(val))


if __name__ == "__main__":
    run()
